(note: this is a temporary file, to be added-to by anybody, and deleted at
release time)

